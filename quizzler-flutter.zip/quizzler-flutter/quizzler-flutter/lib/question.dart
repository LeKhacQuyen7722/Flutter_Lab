class Question {
  final String questionText;
  final bool questionAnswer;

  Question(String q, bool a) :
        questionText = q,
        questionAnswer = a;
}